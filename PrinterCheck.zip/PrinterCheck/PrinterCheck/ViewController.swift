//
//  ViewController.swift
//  PrinterCheck
//
//  Created by Bareeth on 25/01/24.
//

import UIKit
import CoreBluetooth
import Printer

class ViewController: UIViewController {

    var centralManager: CBCentralManager!
    var discoveredPeripherals: [CBPeripheral] = []
    var connectedPeripheral: CBPeripheral!
    var writeCharacteristic: CBCharacteristic?
    var printerName = ""
    let dispatchGroup = DispatchGroup()
    var BluetoothPrinter:BluetoothPrinter?
    private let bluetoothPrinterManager = BluetoothPrinterManager()
    private let dummyPrinter = DummyPrinter()
    private var blocks = [Block]()
    
    @IBOutlet weak var printView: UIView!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var tblView: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        confirmDelegate()
       
    }
    
    
    
    
    func confirmDelegate(){
        centralManager = CBCentralManager(delegate: self, queue: nil)
        tblView.delegate = self
        tblView.dataSource = self
    }

    
    func callAlert(){
        
        let dialogMessage = UIAlertController(title: "Alert", message: "Would you kindly turn on your Bluetooth and make a connection to the device?", preferredStyle: .alert)

        // Create OK button with action handle
        let ok = UIAlertAction(title: "Setting", style: .default, handler: { (action) -> Void in
            print("Ok button tapped")
            
            guard let profileUrl = URL(string: "App-Prefs:root=Blutooth") else {
                return
            }

             if UIApplication.shared.canOpenURL(profileUrl) {

             UIApplication.shared.open(profileUrl, completionHandler: { (success) in

                print(" Profile Settings opened: \(success)")

                })
             }
        })

        // Create Cancel button with action handlder
        let cancel = UIAlertAction(title: "Cancel", style: .cancel) { (action) -> Void in
            print("Cancel button tapped")
        }

        //Add OK and Cancel button to an Alert object
        dialogMessage.addAction(ok)
        dialogMessage.addAction(cancel)

        // Present alert message to user
        self.present(dialogMessage, animated: true, completion: nil)
    }

    @IBAction func printTapped(_ sender: Any) {
        
        guard let connectedPeripheral = connectedPeripheral, let writeCharacteristic = writeCharacteristic else {
            print("Printer not connected or write characteristic not found.")
            return
        }
        
        /*preparePrintDataForLogoAndText*/()
        // Construct the data containing print commands based on the printer language
        var printData = preparePrintingData()
        
        // ESC/POS command for paper2 cut
        
        let paperCutCommand: [UInt8] = [0x1D, 0x56, 0x00]
        let paperCutData = Data(paperCutCommand)
        printData.append(paperCutData)



        // Write the data to the printer
        connectedPeripheral.writeValue(printData, for: writeCharacteristic, type: .withoutResponse)
    }
        
    
    func preparePrintingData() -> Data {
        
        var tic = Ticket()
        
        self.blocks.removeAll()
        blocks.append(.title("Store Name"))
        blocks.append(.blank(1))
        blocks.append(.kv(k: "Test Print", v: "", isBold: true))
        blocks.append(.kv(k: "4302 University Drive Room 203, MADURAI", v: "", isBold: true))
        blocks.append(.kv(k: "625107", v: "", isBold: true))
        blocks.append(.kv(k: "sheik25bareeth@gmail.com", v: "", isBold: true))
        blocks.append(.kv(k: "**79045988", v: "", isBold: true))
                
        self.blocks.append(.dividing)
        
        blocks.append(Block(Text(content: "Delivery", predefined: .alignment(.center), .bold)))
        blocks.append(Block(Text(content: "Due DD/MM/YYYY HH:MM PM", predefined: .alignment(.center), .bold)))
        blocks.append(Block(Text(content: " Order No - XXXXX", predefined: .alignment(.center), .bold)))
        blocks.append(.kv(k: "Items", v: "Price", isBold: true))
        self.blocks.append(.dividing)
        blocks.append(.kv(k: "Pizza", v: "150.00", isBold: true))
        blocks.append(.kv(k: "+ Pepperoni", v: "", isBold: false))
        blocks.append(.kv(k: "+ Sausage", v: "", isBold: false))
        blocks.append(.kv(k: "+ Mushrooms", v: "", isBold: false))
        blocks.append(.kv(k: "+ Onions", v: "", isBold: false))
        blocks.append(.kv(k: "Chicken burgers", v: "22.00", isBold: true))
        blocks.append(.kv(k: "Poha Dosa", v: "9.00", isBold: true))

        self.blocks.append(.dividing)
        blocks.append(.kv(k: "Sub Total", v: "181.00", isBold: false))
        blocks.append(.kv(k: "Delivery Charge", v: "2.00", isBold: false))
        blocks.append(.kv(k: "Bag Charge", v: "0.40", isBold: false))
        blocks.append(.kv(k: "Service Charge", v: "0.50", isBold: false))
        self.blocks.append(.dividing)
        blocks.append(.kv(k: "Total", v: "183.90", isBold: false))
        
        self.blocks.append(.dividing)
        blocks.append(.title("Paid"))
        blocks.append(.blank(1))
        blocks.append(Block(Text(content: "Received at DD/MM/YYYY HH:MM PM", predefined: .alignment(.center), .bold)))
        blocks.append(Block(Text(content: "Thank you for ordering", predefined: .alignment(.center), .bold)))
        
        blocks.append(.plainText("Important if you have allergies call restaurant or check menu"))
            
        
        blocks.append(.qr("https://medium.com/@sheik25bareeth"))
        blocks.append(.blank(1))

        tic.feedLinesOnHead = 0
        tic.feedLinesOnTail = 3
        
        
        let encoding = String.Encoding.utf8

        // Convert the Ticket instance to data

        let ticketData = tic.update(encoding: encoding, block: self.blocks)
        
        let combinedData = ticketData.reduce(Data()) { (result, data) -> Data in
            var mutableResult = result
            mutableResult.append(data)
            return mutableResult
        }

    return combinedData

    }

    
}


extension ViewController : CBCentralManagerDelegate,CBPeripheralDelegate {
    
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        
        if central.state == .poweredOn {
            centralManager?.scanForPeripherals(withServices: nil, options: nil)
        } else {
            callAlert()
        }
        
    }

    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral,
                       advertisementData: [String: Any], rssi RSSI: NSNumber) {
        
        guard peripheral.state != .connected else {
            return
        }
        
        if let peripheralName = peripheral.name {
            // Check if the discovered peripheral is not already in the list
            if !discoveredPeripherals.contains(peripheral) {
                // Add the peripheral to the list
                
                peripheral.delegate = self

                print("Printername:- \(peripheralName)")
                discoveredPeripherals.append(peripheral)
                tblView.reloadData()
                // Reload the table view to display the updated list
//                tableView.reloadData()
            }
        }

        print(discoveredPeripherals)
    }
    
    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        print(characteristic.value as Any)
    }

    func centralManager(_ central: CBCentralManager, didChangeState peripheral: CBPeripheral) {
        
            switch(central.state){
            case.unsupported:
                        print("BLE is not supported")
            case.unauthorized:
                        print("BLE is unauthorized")
            case.unknown:
                        print("BLE is Unknown")
            case.resetting:
                        print("BLE is Resetting")
            case.poweredOff:
                        print("BLE service is powered off")
            case.poweredOn:
                        print("BLE service is powered on")
                        print("Start Scanning")
            centralManager?.scanForPeripherals(withServices: nil, options: nil)
                    default:
                        print("default state")
                    }
        }
    
    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        
        if peripheral.state == .connected {
            peripheral.delegate = self
            peripheral.discoverServices(nil)
        }

    }
    
    

    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        
        if let error = error {
            print("Error discovering services: \(error.localizedDescription)")
            return
        }

        // Iterate through discovered services
        for service in peripheral.services ?? [] {
            let serviceUUID = service.uuid
            print("Discovered service: \(serviceUUID)")
            peripheral.discoverCharacteristics(nil, for: service)
        }
        
    }
    
    
    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        
        if let error = error {
            print("Error discovering characteristics: \(error.localizedDescription)")
            return
        }

        // Iterate through discovered characteristics
        for characteristic in service.characteristics ?? [] {
            let characteristicUUID = characteristic.uuid
            print("Discovered characteristic: \(characteristicUUID)")

            // Check if this is the characteristic you're interested in
            if characteristic.properties.contains(.writeWithoutResponse) {
                writeCharacteristic = characteristic
                print("Write characteristic found")
                // Proceed with your printing logic or other actions
            }
        }
        
    }

    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        print("Peripheral disconnected: \(peripheral.name ?? "Unknown Device")")
        connectedPeripheral = nil
        // Resume scanning if needed
        centralManager?.scanForPeripherals(withServices: nil, options: nil)
    }

    
    func peripheral(_ peripheral: CBPeripheral, didWriteValueFor characteristic: CBCharacteristic, error: Error?) {
        if let error = error {
            print("Error writing to printer: \(error.localizedDescription)")
        } else {
            print("Print command sent successfully!")
        }
    }

}


extension ViewController : UITableViewDelegate,UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return discoveredPeripherals.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "checkCell") as! checkCell
        
        // Configure the cell with the peripheral name
        let peripheral = discoveredPeripherals[indexPath.row]
        cell.txtLbl?.text = peripheral.name ?? "Unknown Device"
        cell.isSelected = (peripheral == connectedPeripheral)
        
        let pheid = UserDefaults.standard.string(forKey: "BluetoothName")
        
        if peripheral.name == pheid{
            cell.txtLbl.textColor = .blue
            centralManager?.stopScan()
            centralManager?.connect(peripheral, options: nil)
            connectedPeripheral = peripheral
        }else{
            cell.txtLbl.textColor = .black
        }
        
        return cell

    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let peripheral = discoveredPeripherals[indexPath.row]
        centralManager?.stopScan()

        // Connect to the selected peripheral
        centralManager?.connect(peripheral, options: nil)
//        peripheral.delegate = self

        // Save the connected peripheral
        connectedPeripheral = peripheral
        
        self.printerName = connectedPeripheral.name ?? ""
        
        UserDefaults.standard.set(connectedPeripheral.name, forKey: "BluetoothName")
        // Reload the table view to update cell highlighting
        tblView.reloadData()
    }

}


class checkCell : UITableViewCell{
    @IBOutlet weak var txtLbl: UILabel!
}
